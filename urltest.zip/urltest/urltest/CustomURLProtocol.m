//
//  CustomURLProtocol.m
//  NSURLProtocolExample
//
//  Created by lujb on 15/6/15.
//  Copyright (c) 2015年 lujb. All rights reserved.
//

#import "CustomURLProtocol.h"

static NSString * const URLProtocolHandledKey = @"URLProtocolHandledKey";

@interface CustomURLProtocol ()<NSURLConnectionDelegate>
@property(nonatomic, readwrite) NSInteger HTTPStatusCode;
//@property (nonatomic,readwrite)AFNetworkReachabilityStatus *NetworkStatus;
@property(nonatomic, readwrite) NSTimeInterval startTime;
@property(nonatomic, readwrite) NSTimeInterval middleTime;

@property(nonatomic, readwrite) NSTimeInterval endTime;

@property (nonatomic, strong) NSURLConnection *connection;


@end

@implementation CustomURLProtocol

+ (BOOL)canInitWithRequest:(NSURLRequest *)request
{//1
    
    //只处理http和https请求
    NSString *scheme = [[request URL] scheme];
    if ( ([scheme caseInsensitiveCompare:@"http"] == NSOrderedSame ||
     [scheme caseInsensitiveCompare:@"https"] == NSOrderedSame))
    {
        //看看是否已经处理过了，防止无限循环
        if ([NSURLProtocol propertyForKey:URLProtocolHandledKey inRequest:request]) {
            return NO;
        }
        
        return YES;
    }
    return NO;
}

+ (NSURLRequest *) canonicalRequestForRequest:(NSURLRequest *)request {
    //2
    return request;
    NSMutableURLRequest *mutableReqeust = [request mutableCopy];
    mutableReqeust = [self redirectHostInRequset:mutableReqeust];
    return mutableReqeust;
}

+ (BOOL)requestIsCacheEquivalent:(NSURLRequest *)a toRequest:(NSURLRequest *)b
{
    return [super requestIsCacheEquivalent:a toRequest:b];
}

- (void)startLoading
{//4
    /* 如果想直接返回缓存的结果，构建一个NSURLResponse对象
    if (cachedResponse) {
        
        NSData *data = cachedResponse.data; //缓存的数据
        NSString *mimeType = cachedResponse.mimeType;
        NSString *encoding = cachedResponse.encoding;
        
        NSURLResponse *response = [[NSURLResponse alloc] initWithURL:self.request.URL
                                                            MIMEType:mimeType
                                               expectedContentLength:data.length
                                                    textEncodingName:encoding];
        
        [self.client URLProtocol:self didReceiveResponse:response cacheStoragePolicy:NSURLCacheStorageNotAllowed];
        [self.client URLProtocol:self didLoadData:data];
        [self.client URLProtocolDidFinishLoading:self];
    */
    
    
    
    self.startTime = NSDate.date.timeIntervalSince1970;
    NSMutableURLRequest *mutableReqeust = [[self request] mutableCopy];
    
    //打标签，防止无限循环
    [NSURLProtocol setProperty:@YES forKey:URLProtocolHandledKey inRequest:mutableReqeust];
    
    self.connection = [NSURLConnection connectionWithRequest:mutableReqeust delegate:self];
    
    
}

- (void)stopLoading
{
    self.endTime = NSDate.date.timeIntervalSince1970;
    //self.startTime
    NSDictionary* segmentation =
    @{
      @"n": self.request.URL.absoluteString,
      @"e": @(self.HTTPStatusCode),
      @"h": self.request.URL.host,
      @"p": self.request.URL.path,
      @"c": @(self.connectionType),
      @"s": @(self.startTime),
      @"u": @(self.endTime)
      };
    NSLog(@"segmentation %@",segmentation);
    [self.connection cancel];
}

#pragma mark - NSURLConnectionDelegate

- (void) connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    self.HTTPStatusCode =((NSHTTPURLResponse*)response).statusCode;
    self.middleTime = NSDate.date.timeIntervalSince1970;
    [self.client URLProtocol:self didReceiveResponse:response cacheStoragePolicy:NSURLCacheStorageNotAllowed];
}

- (void) connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    
    [self.client URLProtocol:self didLoadData:data];
}

- (void) connectionDidFinishLoading:(NSURLConnection *)connection {
    [self.client URLProtocolDidFinishLoading:self];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
     NSLog(@"request faile:%@",error.description);
    [self.client URLProtocol:self didFailWithError:error];
//        NSLog(@"Connection failed! Error - %@ %@",
//              [error localizedDescription],
//              [[error userInfo] objectForKey:NSErrorFailingURLStringKey]);
         NSArray *keys=[[error userInfo] allKeys];
        for (int i=0; i<keys.count; i++)
        {
           NSString *key=[keys objectAtIndex:i];
            NSString *value=[[error userInfo] objectForKey:key];
            NSLog(@"key %@",key);
            NSLog(@"value %@",value);
        }
    
}

#pragma mark -- private

+(NSMutableURLRequest*)redirectHostInRequset:(NSMutableURLRequest*)request
{//3
    if ([request.URL host].length == 0) {
        return request;
    }
    
    NSString *originUrlString = [request.URL absoluteString];
    NSString *originHostString = [request.URL host];
    NSRange hostRange = [originUrlString rangeOfString:originHostString];
    if (hostRange.location == NSNotFound) {
        return request;
    }
    
    //定向到bing搜索主页
    NSString *ip = @"cn.bing.com";
    
    // 替换host
    NSString *urlString = [originUrlString stringByReplacingCharactersInRange:hostRange withString:ip];
    NSURL *url = [NSURL URLWithString:urlString];
    request.URL = url;

    return request;
}






@end
