//
//  CustomURLProtocol.h
//  NSURLProtocolExample
//
//  Created by lujb on 15/6/15.
//  Copyright (c) 2015年 lujb. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"
@interface CustomURLProtocol : NSURLProtocol
@property(nonatomic, readwrite) NSInteger connectionType;

@end
